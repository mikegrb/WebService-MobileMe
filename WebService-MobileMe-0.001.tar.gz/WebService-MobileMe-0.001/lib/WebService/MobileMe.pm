package WebService::MobileMe;
our $VERSION = '0.001';


# ABSTRACT: access MobileMe (in particular FindMyIphone) from Perl

__END__

=pod

=head1 NAME

WebService::MobileMe - access MobileMe (in particular FindMyIphone) from Perl

=head1 VERSION

version 0.001

=head1 DESCRIPTION

Fer doin' stuff with MobileMe